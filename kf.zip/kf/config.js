/**
 * 小程序配置文件
 */

// 此处主机域名是腾讯云解决方案分配的域名
// 小程序后台服务解决方案：https://www.qcloud.com/solution/la

var host = "ystwx.htjs.net"
//var host = "127.0.0.1:8097"  
// var GZH_DM = "10087B1311D1703AE0530A0A111CA938";//郑州国税 
var GZH_DM = "10087B1311D1703AE0530A01231CA938";//代孟阳测试 
// var GZH_DM = "4E36166C515300C4E0530A0A0AACACA6";//湛杰测试
var config = { 
 
    // 下面的地址配合云端 Server 工作
    host,

    //公众号代码
    GZH_DM, 

    // 登录地址，用于建立会话
    loginUrl: `https://${host}/weixin/wysq/oauth.do`,

    // 测试的请求地址，用于测试会话
    requestUrl: `https://${host}/xxzcpt/jkgl/jk.do`,

    // 用code换取openId
    openIdUrl: `https://${host}/weixin/wysq/xcxCode2Session.do`,

    // 测试的信道服务接口
    tunnelUrl: `https://${host}/tunnel`,

    // 生成支付订单的接口
    paymentUrl: `https://${host}/payment`,

    // 发送模板消息接口
    templateMessageUrl: `https://${host}/templateMessage`,

    // 上传文件接口
    uploadFileUrl: `https://${host}/weixin/wysq/upload.do`,

    // 下载示例图片接口
    downloadExampleUrl: `https://${host}/static/weapp.jpg`
};

module.exports = config
