const openIdUrl = require('./config').openIdUrl
const requestUrl = require('./config').requestUrl
const GZH_DM = require('./config').GZH_DM

App({ 
  onLaunch: function () {
    console.log('App Launch') 
  },
  onShow: function () {
    console.log('App Show')
        var self = this
    // wx.request({
    //   url: 'https://yst.12366.ha.cn/xxzcpt/jkgl/jk.do?BEANID=boWzwd&APPTYPE=3&LM_ID=30212&CURPAGE=1&PAGESIZE=20&_=1482480323707',
    //   method:'GET',
    //   data: {
    //     // BEANID: 'boKfLst',
    //     // APPTYPE: 3, 
    //     // START: 0,
    //     // END: 100
    //   },
    //   success: function (result) {
        
    //     console.log('yst.12366.ha.cn请求成功', result)
    //   },

    //   fail: function ({errMsg}) {
    //     console.log('yst.12366.ha.cn请求失败', errMsg)
    //   }
    // })
  },
  onHide: function () {
    console.log('App Hide')
  },
  globalData: {
    hasLogin: false,
    openid: null,
    userInfo: null,
    sflx: null
  },
  getUserInfo: function (cb) {
    var self = this
    if (self.globalData.userInfo) {
      typeof cb == "function" && cb(self.globalData.sflx);
    } else {
      wx.login({
        success: function (res) { 
          console.log('登录后返回信息code:' + res.code)
          self.globalData.hasLogin = true

          if (res.code) {
            //2.code换取openid和session_key
            wx.request({
              url: openIdUrl, 
              method:'GET',
              data: {
                code: res.code,
                GZH_DM: GZH_DM
              },
              success: function (result) { 
                console.log('code换取session_key成功')
                console.log('session_key', result.data.data.session_key)
                console.log('openid', result.data.data.openid)
                self.globalData.openid = result.data.data.openid

                //3.拉取用户身份信息到globalData
                wx.getUserInfo({
                  success: function (res) {
                    self.globalData.userInfo = res.userInfo
                    console.log('拉取用户信息成功')
                    console.log('self.globalData.openid', self.globalData.openid)
                    console.log('self.globalData.userInfo', self.globalData.userInfo)
                    //4.用户信息数据库处理,用户身份信息鉴别（客服Or用户）
                    wx.request({
                      url: requestUrl,
                      data: {
                        BEANID: 'boYhxxcl',
                        APPTYPE: 3,
                        openid: self.globalData.openid,
                        userinfo: self.globalData.userInfo
                      },
                      success: function (result) {
                        console.log('用户信息处理成功，返回数据', result)
                        console.log(result.data.sflx == 1 ? "我是客服" : "我是用户")
                        self.globalData.sflx = result.data.sflx
                        typeof cb == "function" && cb(self.globalData.sflx);
                      },
                      fail: function ({errMsg}) {
                        console.log('用户信息处理请求错误！原因：', errMsg)
                      }
                    })
                  }
                })
              },
              fail: function ({errMsg}) {
                console.log('code换取openid和session_key请求错误！原因：', errMsg)
              }
            })
          } else {
            console.log('获取用户登录态失败！' + res.errMsg)
          }
        }
      });
    }
  }
})
