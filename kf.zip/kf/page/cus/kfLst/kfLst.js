const requestUrl = require('../../../config').requestUrl
const GZH_DM = require('../../../config').GZH_DM

//延时
const duration = 2000
//默认加载数
var pageSize = 15
//获取应用实例
var app = getApp()
Page({
  data: {
    normalSrc: '../../../image/friends.png',
    firstLaunch: true,
    hasMore: true, //是否有更多(当数据加载完后,置为false)
    showLoading: true, //默认显示加载中(当数据加载完后,置为false)
    loadMoreLoading: false, 
    start: 0,
    userInfo: {},
    fskfxx_result:'',
    kfLst:[]
  },
  onShareAppMessage: function () {
    return {
      title: '提示',
      path: '/page/user?id=123',
      success: function(res) {
        // 分享成功
      },
      fail: function(res) {
        // 分享失败 
      }
    }
  },
  applyhandler: function () {
    console.log('申请成为客服')
    wx.navigateTo({ url: '../sqkf/sqkf' })
  },
  onLoad: function () {
    // wx.showShareMenu()
    var self = this
     
    // self.makeRequest() 
    if (!app.globalData.sflx) {   
      //如果没有身份类型信息就去拿  
      app.getUserInfo(function (sflx) { 
        console.log('回调函数sflx=',sflx)
        if (sflx == 2) {
          //如果是用户，请求客服列表数据
          self.makeRequest()
        } else if (sflx == 1) {
          //如果是客服，跳转页面
          wx.redirectTo({
            url: '../../servs/wechat/wechat?id=1'
          })
        } else {
          console.log("身份类型不明")
        }
      })
    }else{
       self.makeRequest() 
    }
  },
  makeRequest: function () {
    console.log("请求链接为:" + requestUrl)
    var self = this
    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boKfLst',
        APPTYPE: 3,
        START: 0,
        END: pageSize
      },
      success: function (result) {
        self.setData({
          kfLst: result.data.data,
          showLoading: false,
        })
        console.log('request success', result)
      },

      fail: function ({errMsg}) {
        console.log('请求出错了,报错信息为:' + errMsg)
      }
    })
  },
  scrollhandler: function (e) {
    // console.log(e)
  },
  loadMore: function () {
    var that = this
    this.setData({
      loadMoreLoading: true
    })
    setTimeout(function () {
      console.log('11')
      that.setData({
        hasMore: false
      })
    }, 3000)
  },
  kindToggle: function (e) {
    var DW_ID = e.currentTarget.id, list = this.data.kfLst;
    console.log('展开' + e.currentTarget.id)

    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].DW_ID == DW_ID) {
        list[i].open = !list[i].open
        // console.log('客服id:' + id + ',开关状态为:' + (list[i].open ? '打开' : '关闭'))
        if (list[i].open){ 
          // 展开点击行客服列表
          console.log('展开')
        } else {
          //折叠点击行客服列表
          console.log('折叠')
        }
      } else {
        list[i].open = false
      }
    }
    this.setData({
      kfLst: list
    });
  }
})
