const requestUrl = require('../../../config').requestUrl
const GZH_DM = require('../../../config').GZH_DM

const duration = 2000
//获取应用实例
var app = getApp()
Page({
  data: {
    kfLst: [],
    userInfo: {},
    fskfxx_result:''
  },
  onShareAppMessage: function () {
    return {
      title: '自定义分享标题',
      path: '/page/user?id=123',
      success: function(res) {
        // 分享成功
      },
      fail: function(res) {
        // 分享失败 
      }
    }
  },
  onLoad: function () {
    wx.showShareMenu()
    var self = this

    // wx.redirectTo({
    //  url: '../../servs/message/message?name =dasdasd&id=ofuvs0KJEaqhJ4tfLb7SGnA5c6Ts'  
    // }) 
    // if (!app.globalData.sflx) {   
    //   //如果没有身份类型信息就去拿  
    //   app.getUserInfo(function (sflx) { 
    //     console.log('回调函数sflx=',sflx)
    //     if (sflx == 2) {
    //       //如果是用户，请求客服列表数据
    //       self.makeRequest()
    //     } else if (sflx == 1) {
    //       //如果是客服，跳转页面
    //       wx.redirectTo({
    //         url: '../../servs/wechat/wechat?id=1'
    //       })
    //     } else {
    //       console.log("身份类型不明")
    //     }
    //   })
    // }else{
    //    self.makeRequest() 
    // }


  },
  sqkf:function(){
      wx.navigateTo({
        url: 'sqkf',
        success: function(res){
          // success
        },
        fail: function(res) {
          // fail
        },
        complete: function(res) {
          // complete
        }
      })
  },
  kfpj:function(){
    console.log("333333")
       wx.navigateTo({ url: '../evaluate/evaluate' })
  },
  makeRequest: function () {
    var self = this
    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boKfLst',
        APPTYPE: 3,
        START: 0,
        END: 100
      },
      success: function (result) {
        self.setData({
          kfLst: result.data.data
        })
        console.log('request success', result)
      },

      fail: function ({errMsg}) {
        console.log('request fail', errMsg)
      }
    })
  }
})
