const requestUrl = require('../../../config').requestUrl
const GZH_DM = require('../../../config').GZH_DM

const duration = 2000
//获取应用实例
var app = getApp()
Page({
  data: {
    showTopTips: false,
    topTipsText: '用户信息不完整',
    showLoading: true, //默认显示加载中(当数据加载完后,置为false)
    hidden: '',
    shzt: 'hidden',
    ycxx: 'hidden',
    msg:''
  },
  onShareAppMessage: function () {
    return {
      title: '自定义分享标题',
      path: '/page/user?id=123',
      success: function (res) {
        // 分享成功
      },
      fail: function (res) {
        // 分享失败 
      }
    }
  },
  onLoad: function () {
    var self = this;
    console.log('客服申请页面初始化，开始调用申请客服状态查询接口')
    if (!app.globalData.openid) {
      app.getUserInfo()
    }
    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boSqkfZtcx',
        APPTYPE: 4,
        OPENID: app.globalData.openid
      },
      success: function (result) {
        var code = result.data.code;
        self.setData({
          showLoading: false
        });

        console.log('查询结果code:' + code)
        if (code == '0'){
          //待审核
          console.log('您有一条申请记录正在审核中')
          self.setData({
            hidden: 'hidden',
            shzt: '',
            msg: '您有一条申请记录正在审核中,请耐心等待',
            ycxx: 'hidden'
          });
        } else if (code == '1') {
          //审核通过
          console.log('您已经是客服')
          self.setData({
            hidden: 'hidden',
            shzt: '',
            msg: '您已经是客服',
            ycxx: 'hidden'
          });
        }else if (code == '2') {
          //审核拒绝
          console.log('您的客服申请被拒绝，可以继续申请')
          self.showTopTips('您上次申请客服被拒绝，可以继续申请')
        } else if (code == '3') {
          //尚未申请客服过
          console.log('尚未申请客服过')
        }

      },
      fail: function ({errMsg}) {
        console.log('request fail', errMsg)
      }
    })


  },
  //表单的提交
  formSubmit: function (e) {
    //先校验用户信息
    if (!this.formCheck(e)) {
      return false
    }
    console.log('form发生了submit事件，携带数据为：', getApp().globalData.openid)
   
    var self = this
    self.setData({
      showLoading: true
    });
    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boSqkf',
        APPTYPE: 4,
        OPENID: getApp().globalData.openid,
        NAME: e.detail.value.NAME,
        DH: e.detail.value.DH,
        DW: e.detail.value.DW
      },
      success: function (result) {
        console.log(result)
        self.setData({
          hidden: 'hidden',
          shzt: '',
          msg: '您有一条申请记录正在审核中,请耐心等待',
          ycxx: 'hidden',
          showLoading: false
        });
        wx.showModal({
          title: '提示',
          content: result.data.msg,
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      },

      fail: function ({errMsg}) {
        console.log('request fail', errMsg)
      }
    })
  },
  /** 
  * 校验输入信息的完整性 
  * @param e 
  */
  formCheck: function (e) {
    var tipsWarnMsg = tipsWarnMsg
    if (isNull(e.detail.value.NAME)) {
      tipsWarnMsg = '用户名不能为空!'
      this.showTopTips(tipsWarnMsg)
      return false
    }
    if (isNull(e.detail.value.DH)) {
      tipsWarnMsg = '电话不能为空!'
      this.showTopTips(tipsWarnMsg)
      return false
    }
    if (isNull(e.detail.value.DW)) {
      tipsWarnMsg = '单位名称不能为空!'
      this.showTopTips(tipsWarnMsg)
      return false
    }
    return true
  },
  /**
 * 显示提示信息
 * @param 提示警告信息
 */
  showTopTips: function (tipsWarnMsg) {
    var that = this;
    this.setData({
      showTopTips: true,
      topTipsText: tipsWarnMsg,
    });
    setTimeout(function () {
      that.setData({
        showTopTips: false,
        topTipsText: tipsWarnMsg,
      });
    }, 2000);
  },
})
/** 
 * 判断是否null 
 * @param data 
 */
function isNull(data) {
  return (data == "" || data == undefined || data == null) ? true : false;
}