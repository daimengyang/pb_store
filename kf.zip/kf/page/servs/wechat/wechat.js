const requestUrl = require('../../../config').requestUrl
const duration = 2000
//获取应用实例
var app = getApp()
var dsrw = null 
Page({
    data: {
        list: [],
        modalHidden: true,
        hidden: true,
        toast1Hidden: true
    },
    onLoad: function () { 
        var self = this
        wx.request({
            url: requestUrl,
            data: {
                BEANID: 'boWeChatLst', 
                APPTYPE: 3,
                SESSION_FROM: app.globalData.openid
            },
            success: function (result) {
                console.log('聊天页面数据初始化请求成功', result)
                self.setData({
                    list: result.data.data
                })
            },

            fail: function ({errMsg}) {
                console.log('聊天页面数据初始化请求失败', errMsg)
            }
        })
    },
    onShow: function () {   
        var self = this
        console.log('WeChat onShow 聊天列表定时器开启')
        dsrw = setInterval(function () {
            wx.request({
                url: requestUrl,
                data: { 
                    BEANID: 'boWeChatLst',
                    APPTYPE: 3,
                    SESSION_FROM: app.globalData.openid
                },
                success: function (result) {
                    console.log('聊天列表定时任务请求成功', result)
                    self.setData({
                        list: result.data.data
                    })
                },

                fail: function ({errMsg}) {
                    console.log('聊天列表定时任务请求失败', errMsg)
                }
            })
        }, 50000000);
    },
    modalTap: function (e) {
        this.setData({
            modalHidden: false
        })
    },
    modalChange: function (e) {
        this.setData({
            modalHidden: true
        }) 
    },
    goPage: function (e) {
        console.log(e)
        var _self = this;
        var newlist = _self.data.list
        var index = e.currentTarget.dataset.index
        newlist[index].WDXXSL = 0;
        _self.setData({
            list: newlist
        })
        wx.navigateTo({
            url: '../message/message?name=' + e.currentTarget.dataset.name + "&id=" + e.currentTarget.dataset.id
        })
    },
    toast1Change: function () {
        this.setData({
            toast1Hidden: true
        })
    },
    onPullDownRefresh: function () {

        // util.getUser(this);

    },
    onHide: function () {
        clearInterval(dsrw) 
        console.log('WeChat onHide取消聊天列表定时器')
    }
})
