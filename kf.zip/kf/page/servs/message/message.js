var app = getApp()
// var getData = require('../../utils/util.js')
const requestUrl = require('../../../config').requestUrl
const uploadFileUrl = require('../../../config').uploadFileUrl
const GZH_DM = require('../../../config').GZH_DM
var dsrw = null;
Page({
  data: {
    text: "这是消息页面，研发中。。。",
    title: "标题",
    userInfo: {},
    content: '',
    message: [],
    animation: {},
    animation_2: {},
    tap: "tapOff",
    FROM_USER_NAME: '',
    height: 0,
    msg: '',
    more: 'ion-ios-plus-outline',
    addandsendbtnimg: '../../../images/plus.png',
    moreBox: false,
    emotionBox: false,
    emotions: [],

  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    console.log('wechat传过来的当前用户openid:' + options.id)
    console.log('wechat传过来的当前用户NC:' + options.name)

    // emoji表情初始化
    let emotions = []
    for (let i = 1; i < 28; i++) {
      let j = i;
      if (j < 10)
        j = '00' + i
      else
        j = '0' + i
      emotions.push({
        src: '../../../images/face-icons-flat/smiley_' + j + '.png',
        id: i,
        name: 'smiley_' + j
      })
    }

    var self = this
    // getData.getMessage(options.id,self)
    self.setData({
      title: options.name,
      userInfo: app.globalData.userInfo,
      FROM_USER_NAME: options.id,
      emotions: emotions
    })

    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boMessageLst',
        APPTYPE: 3,
        SESSION_FROM: app.globalData.openid,
        FROM_USER_NAME: self.data.FROM_USER_NAME,
        START: 0,
        END: 100
      },
      success: function (result) {
        console.log('消息记录初始化数据请求成功', result)
        self.setData({
          message: result.data.data
        })
      },

      fail: function ({errMsg}) {
        console.log('消息记录消息记录初始化数据请求失败', errMsg)
      }
    })
  },
  onReady: function () {
    // 页面渲染完成
    var self = this
    wx.setNavigationBarTitle({
      title: self.data.title
    })
    this.animation = wx.createAnimation();
    this.animation_2 = wx.createAnimation()
  },
  onShow: function () {
    var self = this
    console.log('Message onShow 聊天记录定时器开启')
    dsrw = setInterval(function () {
      wx.request({
        url: requestUrl,
        data: {
          BEANID: 'boMessageLst',
          APPTYPE: 3,
          SESSION_FROM: app.globalData.openid,
          FROM_USER_NAME: self.data.FROM_USER_NAME,
          START: 0,
          END: 100
        },
        success: function (result) {
          console.log('聊天记录定时器数据请求成功', result)
          self.setData({
            message: result.data.data
          })
        },

        fail: function ({errMsg}) {
          console.log('聊天记录定时器数据数据请求失败', errMsg)
        }
      })
    }, 300000);
  },
  onHide: function () {
    clearInterval(dsrw)
    console.log('Message onHide聊天记录定时器关闭')
  },
  onUnload: function () {
    // 页面关闭
     clearInterval(dsrw)
    console.log('Message onUnload聊天记录定时器关闭')
  },
  // 自定义键盘操作
  emotionBtn() {
    console.log('表情')
    this.setData({
      moreBox: false,
      emotionBox: (this.data.tap == 'tapOff') ? true : false
    })

    if (this.data.tap == "tapOff") {
      this.animation_2.height(this.data.height - 200).step();
      this.setData({ animation_2: this.animation_2.export() })
      this.setData({
        tap: "tapOn"
      })
    } else {
      this.animation_2.height(this.data.height - 50).step();
      this.setData({ animation_2: this.animation_2.export() })
      this.setData({
        tap: "tapOff"
      })
    }
  },

  elseBtn: function () {
    console.log('点击添加/发送按钮事件');
    // clearInterval(dsrw)
    console.log('Message elseBtn聊天记录定时器关闭')
    var self = this;
    if (this.data.more == 'ion-ios-send') {
      console.log(this.data.msg)
      self.fskfxx()
      this.setData({
        msg: '',
        more: 'ion-ios-plus-outline',
        addandsendbtnimg: '../../../images/send.png'
      })
      this.animation_2.height(this.data.height - 50).step();
      this.setData({ animation_2: this.animation_2.export() })
      this.setData({
        tap: "tapOff"
      })
      return
    }
    this.setData({
      emotionBox: false,
      moreBox: (this.data.tap == 'tapOff') ? true : false
    })

    if (this.data.tap == "tapOff") {
      this.animation_2.height(this.data.height - 200).step();
      this.setData({ animation_2: this.animation_2.export() })
      this.setData({
        tap: "tapOn"
      })
    } else {
      this.animation_2.height(this.data.height - 50).step();
      this.setData({ animation_2: this.animation_2.export() })
      this.setData({
        tap: "tapOff"
      })
    }

    // if (self.data.tap == "tapOff") {
    //   self.animation_2.height("55%").step();
    //   self.setData({ animation_2: self.animation_2.export() })
    //   self.setData({
    //     tap: "tapOn"
    //   })
    // } else {
    //   self.animation_2.height("90%").step();
    //   self.setData({ animation_2: self.animation_2.export() })
    //   self.setData({
    //     tap: "tapOff"
    //   })
    // }
  },
  tapscroll(e) {
    console.log('tapscroll')
    this.setData({
      emotionBox: false,
      moreBox: false
    })

    this.animation_2.height(this.data.height - 50).step();
    this.setData({ animation_2: this.animation_2.export() })
    this.setData({
      tap: "tapOff"
    })
  },
  chooseEmotion(e) {
    console.log('emotion:' + e.target.dataset.name)
    this.setData({
      msg: this.data.msg + '[' + e.target.dataset.name + ']',
      more: 'ion-ios-send',
      addandsendbtnimg: '../../../images/send.png',
    })
  },
  chooseImg: function () {
    var self = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths
        var t = self.data.message
        t.push({
          MSG_TYPE:'image',
          FSLX:'2',
          PIC_URL: tempFilePaths[0],
        })
        self.setData({
          message: t
        })
      
      //上传到服务器
      wx.uploadFile({
        url: uploadFileUrl, 
        filePath: tempFilePaths[0],
        name: 'upload',
        formData: {
          GZH_DM: GZH_DM,
          SESSION_FROM: app.globalData.openid,
          FROM_USER_NAME: self.data.FROM_USER_NAME,
          MSG_TYPE:'image'
        },
        success: function (res) {
          var data = res.data
          //do something
        }
      })
      }
    })
  },
  listenerInput: function (e) {
    console.log('监听输入框的输入信息，当有数据时，添加按钮变为发送按钮')
    this.setData({
      content: e.detail.value,
      more: (e.detail.value) ? 'ion-ios-send' : 'ion-ios-plus-outline',
      addandsendbtnimg: (e.detail.value) ? '../../../images/send.png' : '../../../images/plus.png',
    })
  },
  fskfxx: function () {
    console.log('发送客服消息')
    var self = this
    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boFskfxx',
        APPTYPE: 3,
        GZH_DM: GZH_DM,
        SESSION_FROM: app.globalData.openid,
        FROM_USER_NAME: self.data.FROM_USER_NAME,
        MSG_TYPE: 'text',
        CONTENT: self.data.content
      },
      success: function (result) {
        var r = '小程序返回：\n' + result.statusCode + '\n' + 'errorMsg' + result.errMsg
          + '\n 后台服务返回: \n' + result.data.code + '\n' + result.data.msg
        self.setData({
          fskfxx_result: r
        })
        console.log('发送的客服消息成功', result)
      },

      fail: function ({errMsg}) {
        var r = result.statusCode + '\n' + 'errorMsg' + result.errMsg
          + '\n' + result.data.code + '\n' + result.data.msg
        self.setData({
          fskfxx_result: r
        })
        console.log('发送的客服消息失败', errMsg)
      }
    })
  },
  formSubmit: function (e) {
    var self = this
    console.log('form发生了submit事件，formid为：', e.detail.formId)
    wx.request({
      url: requestUrl,
      data: {
        BEANID: 'boXcxPTQrcode',
        APPTYPE: 3,
        GZH_DM: GZH_DM,
        SESSION_FROM: app.globalData.openid,
        FROM_USER_NAME: self.data.FROM_USER_NAME
      },
      success: function (result) {
        console.log('发起评价成功', result)
      },

      fail: function ({errMsg}) {
        console.log('发起评价失败', errMsg)
      }
    })
  },
})